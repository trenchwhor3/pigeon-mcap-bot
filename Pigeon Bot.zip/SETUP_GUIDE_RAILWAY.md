# 🚀 COMPLETE SETUP GUIDE - Pigeon Twitter Bot on Railway
## For Beginners - No Coding Experience Needed!

This guide will help you set up your automated Twitter bot in about 15-20 minutes.

**🌟 Your bot includes LIVE market cap tracking!** It automatically fetches Pigeon's current price and market cap from DexScreener, so your tweets show real data like:
- Current market cap
- Distance to $941M target
- Special celebration when target is reached! 🎉

---

## 📋 STEP 1: Get Twitter API Credentials (10 minutes)

### 1.1 Create a Twitter Developer Account

1. Go to https://developer.twitter.com/en/portal/dashboard
2. Click **"Sign up"** (if you don't have a developer account)
3. Use your Twitter account to log in
4. Fill out the application:
   - **What's your use case?** → Select "Making a bot"
   - **Describe your app:** Type something like:
     ```
     "Creating an automated bot that posts daily market cap updates for 
     tracking purposes. Posts once per day, no spam or automated engagement."
     ```
5. Accept the terms and submit
6. **Wait for approval** (usually instant, sometimes takes a few hours)

### 1.2 Create Your App

1. Once approved, click **"+ Create App"**
2. Give it a name: `pigeon-mcap-bot` (or any unique name)
3. Click **Create**

### 1.3 Get Your API Keys

1. Click on your app name
2. Go to **"Keys and tokens"** tab
3. You'll see **API Key and Secret** - click **"Regenerate"** if needed
4. **SAVE THESE IMMEDIATELY** (you can't see them again):
   ```
   API Key: xxxxxxxxxxxxxxxxxxxxx
   API Secret: xxxxxxxxxxxxxxxxxxxxx
   ```

5. Scroll down to **"Access Token and Secret"**
6. Click **"Generate"**
7. **SAVE THESE TOO:**
   ```
   Access Token: xxxxxxxxxxxxxxxxxxxxx
   Access Token Secret: xxxxxxxxxxxxxxxxxxxxx
   ```

8. Scroll to **"Bearer Token"**
9. Click **"Generate"** if needed
10. **SAVE THIS:**
    ```
    Bearer Token: xxxxxxxxxxxxxxxxxxxxx
    ```

### 1.4 Set Permissions

1. Go to **"Settings"** tab
2. Scroll to **"User authentication settings"**
3. Click **"Set up"**
4. Enable **"Read and Write"** permissions
5. For "Type of App" select **"Automated App or Bot"**
6. Fill in required fields:
   - **App name:** pigeon-mcap-bot
   - **Website:** https://twitter.com/your_bot_username
   - **Callback URL:** https://example.com (just placeholder)
7. Save changes

**✅ You now have all 5 credentials! Keep them safe.**

---

## 📋 STEP 2: Prepare Your Bot Files (5 minutes)

### 2.1 Download the Bot Files

You already have these files! Make sure you have:
- `twitter_pigeon_bot_enhanced.py`
- `requirements.txt`
- `.env.example`

### 2.2 Create a GitHub Account (if you don't have one)

1. Go to https://github.com
2. Click **"Sign up"**
3. Follow the steps to create your free account
4. Verify your email

### 2.3 Create a New Repository

1. Log into GitHub
2. Click the **"+"** in top right → **"New repository"**
3. Repository name: `pigeon-twitter-bot`
4. Make it **Public** (required for Railway free tier)
5. Check ✅ **"Add a README file"**
6. Click **"Create repository"**

### 2.4 Upload Your Bot Files

1. In your new repository, click **"Add file"** → **"Upload files"**
2. Drag and drop these files:
   - `twitter_pigeon_bot_live_mcap.py` (the main bot with live market cap!)
   - `requirements.txt`
   - `.gitignore`
3. **DO NOT upload .env or any file with your credentials!**
4. Scroll down and click **"Commit changes"**

### 2.5 Create a Procfile

1. In your repository, click **"Add file"** → **"Create new file"**
2. Name it: `Procfile` (exactly like this, no extension)
3. Paste this content:
   ```
   worker: python twitter_pigeon_bot_live_mcap.py
   ```
4. Click **"Commit new file"**

---

## 📋 STEP 3: Deploy to Railway (5 minutes)

### 3.1 Create Railway Account

1. Go to https://railway.app
2. Click **"Login"**
3. Choose **"Login with GitHub"**
4. Authorize Railway to access your GitHub

### 3.2 Create a New Project

1. Click **"New Project"**
2. Select **"Deploy from GitHub repo"**
3. Click **"Configure GitHub App"**
4. Give Railway access to your `pigeon-twitter-bot` repository
5. Select your `pigeon-twitter-bot` repository

### 3.3 Add Environment Variables (Your API Keys)

1. Your project will start deploying
2. Click on your project
3. Click **"Variables"** tab
4. Click **"+ New Variable"**
5. Add each of these (click "+ New Variable" for each):

   ```
   API_KEY = [paste your API Key here]
   API_SECRET = [paste your API Secret here]
   ACCESS_TOKEN = [paste your Access Token here]
   ACCESS_TOKEN_SECRET = [paste your Access Token Secret here]
   BEARER_TOKEN = [paste your Bearer Token here]
   BOT_MODE = scheduled
   POST_TIME = 09:00
   ```

6. After adding all variables, click **"Deploy"**

### 3.4 Verify Deployment

1. Go to **"Deployments"** tab
2. Wait for it to say **"SUCCESS"** (takes 1-2 minutes)
3. Click **"View Logs"** to see if bot started:
   - You should see: "🤖 Bot started!"
   - Shows current day count
   - Shows next post time

---

## 📋 STEP 4: Test Your Bot (2 minutes)

### 4.1 Run a Test Post

To test immediately without waiting:

1. In Railway, go to **"Variables"** tab
2. Change `BOT_MODE` from `scheduled` to `once`
3. Go to **"Deployments"**
4. Click **"Restart"** (top right)
5. Check your Twitter - you should see: "Day 1 of posting pigeon under 941M mcap"

### 4.2 Switch Back to Scheduled Mode

1. Go back to **"Variables"**
2. Change `BOT_MODE` from `once` back to `scheduled`
3. Click **"Restart"** again
4. Your bot will now post automatically every day at 9 AM!

---

## ⚙️ CUSTOMIZATION OPTIONS

### Change Posting Time

1. Go to Railway **"Variables"**
2. Edit `POST_TIME` variable
3. Use 24-hour format: `14:30` for 2:30 PM, `21:00` for 9 PM
4. Restart deployment

### Change Tweet Text

1. Go to your GitHub repository
2. Click on `twitter_pigeon_bot_enhanced.py`
3. Click the pencil icon (Edit)
4. Find line 61: `tweet_text = f"Day {self.data['day_count']} of posting pigeon under 941M mcap"`
5. Change to whatever you want:
   ```python
   tweet_text = f"Day {self.data['day_count']} of posting pigeon under 941M mcap 🐦💎"
   ```
6. Scroll down, click **"Commit changes"**
7. Railway will automatically redeploy with your changes!

---

## 🐛 TROUBLESHOOTING

### ❌ "Authentication Error"
- Double-check all 5 API credentials in Railway Variables
- Make sure there are no extra spaces before/after the values
- Verify your Twitter app has "Read and Write" permissions

### ❌ "Bot not posting"
- Check Railway logs for errors
- Verify `BOT_MODE` is set to `scheduled`
- Make sure deployment shows "SUCCESS"

### ❌ "Already posted today"
- This is normal! Bot won't post twice on the same day
- Wait until tomorrow, or change to `once` mode to force a post

### ❌ Railway says "Deployment failed"
- Check that `Procfile` is spelled exactly right (capital P, no extension)
- Verify `requirements.txt` was uploaded correctly

### Need help?
- Railway Logs show exactly what went wrong
- Check the "Deployments" tab → Click on latest deployment → "View Logs"

---

## 📊 MONITORING YOUR BOT

### Check if Bot is Running

1. Go to Railway dashboard
2. Your project should show **"Active"**
3. Click **"View Logs"** to see bot status

### Check Post History

1. The bot creates a `bot_data.json` file that tracks:
   - Current day count
   - Last post date
   - Start date

### Free Tier Limits

Railway free tier includes:
- $5 credit per month
- Your bot uses minimal resources
- Should run 24/7 for free with no issues

---

## 🎉 YOU'RE DONE!

Your bot is now:
✅ Running 24/7 on Railway's cloud
✅ Posting automatically every day at your scheduled time
✅ Tracking days persistently
✅ Completely hands-off!

**Your bot will post:** "Day 1 of posting pigeon under 941M mcap"
**Then tomorrow:** "Day 2 of posting pigeon under 941M mcap"
**And so on, forever!**

---

## 💡 NEXT STEPS

Want to add more features?
- Track actual market cap from an API
- Add emojis or hashtags
- Post at multiple times per day
- Add charts or images

Let me know what you'd like to add!
