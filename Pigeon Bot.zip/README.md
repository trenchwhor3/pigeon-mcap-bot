# 🐦 Pigeon Twitter Bot - Live Market Cap Tracker

Automated Twitter bot that posts daily updates tracking Pigeon's journey to $941M market cap!

## 🌟 Features

✅ **Live Market Cap Tracking** - Fetches real-time data from DexScreener  
✅ **Daily Posts** - Automatically tweets once per day at your chosen time  
✅ **Progress Updates** - Shows current mcap, target, and distance remaining  
✅ **Celebration Mode** - Special tweet when $941M is reached! 🎉  
✅ **Persistent Counter** - Never loses track of days  
✅ **Free Hosting** - Runs 24/7 on Railway's free tier  

---

## 📊 What It Posts

**Example Daily Tweet:**
```
Day 15 of posting pigeon under 941M mcap

Current: $167.5K
Target: $941M
To go: $940.83M 🐦
```

**When Target Reached:**
```
🎉 PIGEON HAS REACHED 941M MCAP! 🚀

Current Market Cap: $941.2M

It took 15 days! LFG! 🐦💎
```

---

## 🚀 Quick Setup (15 minutes)

### Step 1: Get Twitter API Credentials (10 min)

1. Go to https://developer.twitter.com/en/portal/dashboard
2. Create a developer account and new app
3. Generate these 5 credentials:
   - API Key
   - API Secret
   - Access Token
   - Access Token Secret
   - Bearer Token
4. Set app permissions to **"Read and Write"**

📖 **Detailed instructions:** See `SETUP_GUIDE_RAILWAY.md` → Step 1

### Step 2: Create GitHub Repository (3 min)

1. Create account at https://github.com (if needed)
2. Create new **public** repository: `pigeon-twitter-bot`
3. Upload these files:
   - ✅ `twitter_pigeon_bot_live_mcap.py`
   - ✅ `requirements.txt`
   - ✅ `Procfile`
   - ✅ `.gitignore`
4. **DO NOT upload `.env` file!**

### Step 3: Deploy to Railway (2 min)

1. Go to https://railway.app
2. Login with GitHub
3. Create new project from your GitHub repo
4. Add environment variables:
   ```
   API_KEY = [your_api_key]
   API_SECRET = [your_api_secret]
   ACCESS_TOKEN = [your_access_token]
   ACCESS_TOKEN_SECRET = [your_access_token_secret]
   BEARER_TOKEN = [your_bearer_token]
   BOT_MODE = scheduled
   POST_TIME = 09:00
   ```
5. Wait for deployment to complete (1-2 minutes)

### Step 4: Test It! (1 min)

1. Change `BOT_MODE` to `once` in Railway variables
2. Restart deployment
3. Check Twitter for your first post!
4. Change `BOT_MODE` back to `scheduled`
5. Your bot is now live! 🎉

---

## 📁 Files Included

| File | Description |
|------|-------------|
| `twitter_pigeon_bot_live_mcap.py` | **Main bot** - Live market cap tracking |
| `twitter_pigeon_bot_enhanced.py` | Simple version without live data |
| `requirements.txt` | Python dependencies |
| `Procfile` | Railway deployment config |
| `.env.example` | Template for credentials |
| `.gitignore` | Security - prevents credential leaks |
| `SETUP_GUIDE_RAILWAY.md` | **Step-by-step setup guide** |
| `SETUP_GUIDE_LIVE_MCAP.md` | Additional info on live features |
| `QUICK_REFERENCE.md` | Quick checklist |

---

## ⚙️ Configuration

### Change Posting Time

In Railway Variables, edit `POST_TIME`:
- `09:00` = 9 AM
- `14:30` = 2:30 PM
- `21:00` = 9 PM

### Change Target Market Cap

Edit line 26 in `twitter_pigeon_bot_live_mcap.py`:
```python
self.target_mcap = 500_000_000  # Change to $500M
```

### Customize Tweet Text

Edit around line 100 in the bot file:
```python
tweet_text = f"Day {self.data['day_count']} of posting pigeon under 941M mcap 🚀🐦💎"
```

---

## 🐛 Troubleshooting

**Bot not posting?**
- Check Railway logs for errors
- Verify `BOT_MODE = scheduled`
- Ensure deployment shows "SUCCESS"

**"Authentication failed"?**
- Double-check all 5 credentials in Railway
- Verify app has "Read and Write" permissions
- Make sure no extra spaces in credentials

**"Already posted today"?**
- Normal! Bot only posts once per day
- Set `BOT_MODE = once` to force a test post

**Wrong market cap showing?**
- Bot fetches from DexScreener API
- Uses most liquid pool
- Verify at: https://dexscreener.com/solana/fxrvcgmqfgj3wrmuxgh8qhvlau3q4t7jqekboqhvecr7

---

## 📖 Full Documentation

- **Complete Setup:** `SETUP_GUIDE_RAILWAY.md`
- **Live Features:** `SETUP_GUIDE_LIVE_MCAP.md`  
- **Quick Reference:** `QUICK_REFERENCE.md`

---

## 💡 Tips

- Monitor logs in Railway dashboard daily
- Backup `bot_data.json` to preserve day count
- Test with `BOT_MODE=once` before going live
- Railway free tier = $5/month credit (plenty for this bot)

---

## 🎯 Token Information

**Pigeon Token**
- Contract: `4fSWEw2wbYEUCcMtitzmeGUfqinoafXxkhqZrA9Gpump`
- Chain: Solana
- DEX: PumpSwap via Pump.fun
- Track: https://dexscreener.com/solana/fxrvcgmqfgj3wrmuxgh8qhvlau3q4t7jqekboqhvecr7

---

## 🚀 Ready to Launch?

1. Follow `SETUP_GUIDE_RAILWAY.md` for detailed steps
2. Upload files to GitHub
3. Deploy to Railway
4. Your bot runs 24/7 automatically!

**Questions?** Check the troubleshooting section or setup guides!

---

## 📜 License

MIT - Use freely for your own projects!
