# 🎯 QUICK REFERENCE CARD

## Your Bot Setup Checklist

**🌟 Bot Features:**
- Tracks LIVE market cap from DexScreener
- Posts daily with real price data
- Celebrates when $941M is reached!
- Runs 24/7 on Railway (free)

### Phase 1: Twitter API (10 min)
- [ ] Go to developer.twitter.com/en/portal/dashboard
- [ ] Create developer account & app
- [ ] Generate 5 credentials:
  - [ ] API Key
  - [ ] API Secret  
  - [ ] Access Token
  - [ ] Access Token Secret
  - [ ] Bearer Token
- [ ] Set app permissions to "Read and Write"
- [ ] Save all credentials somewhere safe!

### Phase 2: GitHub (5 min)
- [ ] Create GitHub account (github.com)
- [ ] Create new public repository: `pigeon-twitter-bot`
- [ ] Upload these files:
  - [ ] twitter_pigeon_bot_enhanced.py
  - [ ] requirements.txt
  - [ ] Procfile
  - [ ] .gitignore
- [ ] Do NOT upload .env file!

### Phase 3: Railway (5 min)
- [ ] Go to railway.app
- [ ] Login with GitHub
- [ ] Create new project from your GitHub repo
- [ ] Add environment variables (all 5 API credentials)
- [ ] Add BOT_MODE = scheduled
- [ ] Add POST_TIME = 09:00
- [ ] Wait for deployment SUCCESS

### Phase 4: Test (2 min)
- [ ] Change BOT_MODE to "once"
- [ ] Restart deployment
- [ ] Check Twitter for test post
- [ ] Change BOT_MODE back to "scheduled"
- [ ] Restart deployment again

## ✅ DONE!
Your bot will now post every day automatically!

---

## Important Variables for Railway

```
API_KEY = your_api_key_here
API_SECRET = your_api_secret_here
ACCESS_TOKEN = your_access_token_here
ACCESS_TOKEN_SECRET = your_access_token_secret_here
BEARER_TOKEN = your_bearer_token_here
BOT_MODE = scheduled
POST_TIME = 09:00
```

---

## Files You Need

✅ twitter_pigeon_bot_live_mcap.py (the bot with LIVE market cap!)
✅ requirements.txt (dependencies)
✅ Procfile (tells Railway how to run)
✅ .gitignore (security)
❌ .env (NEVER upload this!)

---

## Common Issues

**"Authentication failed"**
→ Check all 5 credentials are correct in Railway Variables

**"Bot not posting"**
→ Make sure BOT_MODE = scheduled
→ Check Railway logs for errors

**"Already posted today"**  
→ Normal! Bot posts once per day
→ Use BOT_MODE = once to force a test post

**Want to change post time?**
→ Edit POST_TIME variable in Railway (use 24hr format)

**Need help?**
→ Check Railway deployment logs for detailed error messages
